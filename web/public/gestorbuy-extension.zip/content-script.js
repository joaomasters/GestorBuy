"use strict";
(() => {
  // src/content-script.ts
  function queryText(selectors) {
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el?.textContent?.trim()) return el.textContent.trim();
    }
    return null;
  }
  function parseBRLNumber(raw) {
    const cleaned = raw.replace(/[^\d.,]/g, "");
    if (cleaned.includes(",")) {
      return parseFloat(cleaned.replace(/\./g, "").replace(",", "."));
    }
    return parseFloat(cleaned.replace(/\./g, ""));
  }
  function extractTitle() {
    return queryText([".ui-pdp-title", "h1.ui-pdp-title", "h1"]) ?? document.title.replace(/\s*\|\s*MercadoLivre.*$/i, "").trim();
  }
  function extractPrice() {
    const candidates = [
      ".ui-pdp-price__second-line .andes-money-amount__fraction",
      ".ui-pdp-price__main-container .andes-money-amount__fraction",
      ".andes-money-amount__fraction"
    ];
    for (const selector of candidates) {
      const fractionEl = document.querySelector(selector);
      if (!fractionEl?.textContent) continue;
      const whole = parseBRLNumber(fractionEl.textContent);
      if (Number.isNaN(whole) || whole <= 0) continue;
      const centsEl = fractionEl.closest(".andes-money-amount")?.querySelector(".andes-money-amount__cents");
      const cents = centsEl?.textContent ? parseInt(centsEl.textContent, 10) : 0;
      return whole + (Number.isNaN(cents) ? 0 : cents / 100);
    }
    return 0;
  }
  function extractSoldQuantity() {
    const scoped = queryText([".ui-pdp-subtitle", ".ui-pdp-header__subtitle"]);
    const scopedMatch = scoped?.match(/([\d.,]+)\s*vendid/i);
    if (scopedMatch) return Math.round(parseBRLNumber(scopedMatch[1]));
    const bodyMatch = document.body.innerText.match(/([\d.,]+)\s*vendid/i);
    if (bodyMatch) return Math.round(parseBRLNumber(bodyMatch[1]));
    return 0;
  }
  function extractSellerNickname() {
    const scoped = queryText([
      ".ui-pdp-seller__link-trigger-button",
      ".ui-pdp-seller__header__title"
    ]);
    if (scoped) return scoped;
    const officialStoreMatch = document.body.innerText.match(/Loja [Oo]ficial\s+([^\n]+)/);
    if (officialStoreMatch) return officialStoreMatch[1].trim().replace(/^de\s+/i, "");
    const soldByMatch = document.body.innerText.match(/Vendido por\s+([^\n]+)/i);
    return soldByMatch ? soldByMatch[1].trim() : "";
  }
  function extractPermalink() {
    const canonical = document.querySelector('link[rel="canonical"]');
    return canonical?.getAttribute("href") ?? window.location.href;
  }
  function extractItem() {
    return {
      externalItemId: window.location.href,
      title: extractTitle(),
      permalink: extractPermalink(),
      sellerNickname: extractSellerNickname(),
      price: extractPrice(),
      soldQuantity: extractSoldQuantity()
    };
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "EXTRACT_ITEM") {
      sendResponse(extractItem());
    }
    return true;
  });
})();
//# sourceMappingURL=content-script.js.map
