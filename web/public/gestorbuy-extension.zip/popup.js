"use strict";
(() => {
  // src/popup.ts
  function $(id) {
    const el = document.getElementById(id);
    if (!el) throw new Error(`elemento #${id} n\xE3o encontrado no popup.html`);
    return el;
  }
  var loginView = $("login-view");
  var appView = $("app-view");
  var emailInput = $("email");
  var passwordInput = $("password");
  var loginBtn = $("login-btn");
  var loginError = $("login-error");
  var notProductPage = $("not-product-page");
  var itemPreview = $("item-preview");
  var saveBtn = $("save-btn");
  var saveMessage = $("save-message");
  var logoutBtn = $("logout");
  var currentItem = null;
  async function refreshView() {
    const { token } = await chrome.runtime.sendMessage({ type: "GET_TOKEN" });
    if (!token) {
      loginView.hidden = false;
      appView.hidden = true;
      return;
    }
    loginView.hidden = true;
    appView.hidden = false;
    await loadCurrentPageItem();
  }
  async function loadCurrentPageItem() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !tab.url?.includes("mercadolivre.com.br")) {
      notProductPage.hidden = false;
      itemPreview.hidden = true;
      saveBtn.hidden = true;
      return;
    }
    try {
      const item = await chrome.tabs.sendMessage(tab.id, {
        type: "EXTRACT_ITEM"
      });
      currentItem = item;
      notProductPage.hidden = true;
      itemPreview.hidden = false;
      saveBtn.hidden = false;
      $("preview-title").textContent = item.title || "(n\xE3o identificado)";
      $("preview-price").textContent = item.price ? item.price.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) : "(n\xE3o identificado)";
      $("preview-sold").textContent = item.soldQuantity ? String(item.soldQuantity) : "(n\xE3o identificado)";
      $("preview-seller").textContent = item.sellerNickname || "(n\xE3o identificado)";
    } catch {
      notProductPage.hidden = false;
      itemPreview.hidden = true;
      saveBtn.hidden = true;
    }
  }
  loginBtn.addEventListener("click", async () => {
    loginError.hidden = true;
    loginBtn.disabled = true;
    loginBtn.textContent = "Entrando...";
    const result = await chrome.runtime.sendMessage({
      type: "LOGIN",
      email: emailInput.value,
      password: passwordInput.value
    });
    loginBtn.disabled = false;
    loginBtn.textContent = "Entrar";
    if (!result.ok) {
      loginError.textContent = result.error;
      loginError.hidden = false;
      return;
    }
    await refreshView();
  });
  saveBtn.addEventListener("click", async () => {
    if (!currentItem) return;
    saveBtn.disabled = true;
    saveBtn.textContent = "Salvando...";
    saveMessage.hidden = true;
    const result = await chrome.runtime.sendMessage({
      type: "SAVE_ITEM",
      item: {
        external_item_id: currentItem.externalItemId,
        title: currentItem.title,
        permalink: currentItem.permalink,
        seller_nickname: currentItem.sellerNickname,
        price: currentItem.price,
        sold_quantity: currentItem.soldQuantity,
        available_quantity: 0
      }
    });
    saveBtn.disabled = false;
    saveBtn.textContent = "Salvar no GestorBuy";
    saveMessage.hidden = false;
    saveMessage.className = result.ok ? "success" : "error";
    saveMessage.textContent = result.ok ? "Salvo! Confira em /mining no GestorBuy." : result.error ?? "N\xE3o foi poss\xEDvel salvar";
  });
  logoutBtn.addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ type: "LOGOUT" });
    await refreshView();
  });
  refreshView();
})();
//# sourceMappingURL=popup.js.map
