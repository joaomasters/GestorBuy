"use strict";
(() => {
  // src/config.ts
  var API_URL = "https://gestorbuy-production.up.railway.app";
  var STORAGE_KEY_TOKEN = "gestorbuy_token";

  // src/background.ts
  async function getToken() {
    const stored = await chrome.storage.local.get(STORAGE_KEY_TOKEN);
    return stored[STORAGE_KEY_TOKEN] ?? null;
  }
  async function handleLogin(email, password) {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.token) {
      return { ok: false, error: data.error ?? "N\xE3o foi poss\xEDvel entrar" };
    }
    await chrome.storage.local.set({ [STORAGE_KEY_TOKEN]: data.token });
    return { ok: true };
  }
  async function handleSaveItem(item) {
    const token = await getToken();
    if (!token) {
      return { ok: false, error: "Fa\xE7a login na extens\xE3o primeiro" };
    }
    const res = await fetch(`${API_URL}/mining/items/ingest`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(item)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return { ok: false, error: data.error ?? `Erro ${res.status}` };
    }
    return { ok: true };
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    (async () => {
      switch (message.type) {
        case "LOGIN":
          sendResponse(await handleLogin(message.email, message.password));
          break;
        case "GET_TOKEN":
          sendResponse({ token: await getToken() });
          break;
        case "LOGOUT":
          await chrome.storage.local.remove(STORAGE_KEY_TOKEN);
          sendResponse({ ok: true });
          break;
        case "SAVE_ITEM":
          sendResponse(await handleSaveItem(message.item));
          break;
      }
    })();
    return true;
  });
})();
//# sourceMappingURL=background.js.map
